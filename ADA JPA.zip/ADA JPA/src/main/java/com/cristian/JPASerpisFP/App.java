package com.cristian.JPASerpisFP;

import com.cristian.JPASerpisFP.Domain.Entity.FinalProject;
import com.cristian.JPASerpisFP.Domain.Entity.Group;
import com.cristian.JPASerpisFP.Domain.Entity.Student;
import com.cristian.JPASerpisFP.Domain.Entity.Subject;
import com.cristian.JPASerpisFP.model.dao.GroupDAO;

import java.util.HashSet;
import java.util.Set;

public class App {


}
