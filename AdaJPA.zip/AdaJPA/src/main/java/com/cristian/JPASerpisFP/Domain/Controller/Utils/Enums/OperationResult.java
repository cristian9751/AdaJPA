package com.cristian.JPASerpisFP.Domain.Controller.Utils.Enums;

public enum OperationResult {
	OK,
	NOT_EXISTS,
	ALREADY_EXISTS,
	COMMON_ERROR,
	NOT_DELETE,
	
}
