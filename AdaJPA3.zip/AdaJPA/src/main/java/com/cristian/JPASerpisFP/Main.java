package com.cristian.JPASerpisFP;
import static com.cristian.JPASerpisFP.JPASerpisFPApp.*;

import java.util.Scanner;

import com.cristian.JPASerpisFP.model.PersistenceManager;


public class Main {

	
	public static void main(String[] args) {
		runApp(false);
	}

}
